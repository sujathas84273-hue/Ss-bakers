import React, { useState, useEffect } from "react";
import { ShoppingBag, Menu, X, Search } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import SearchOverlay from "./SearchOverlay";

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <>
      <nav
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 border-b ${isScrolled ? "bg-ink/90 backdrop-blur-md border-white/10 py-4 shadow-xl" : "bg-transparent border-transparent py-6 md:py-8"}`}
      >
        <div className="max-w-7xl mx-auto px-6 lg:px-10 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              className="lg:hidden text-white focus:outline-none"
              onClick={() => setIsMobileMenuOpen(true)}
            >
              <Menu size={24} />
            </button>
            <div className="text-2xl font-bold tracking-tighter font-serif uppercase text-white">
              SS<span className="text-golden font-light">BAKERY</span>
            </div>
          </div>

          <div className="hidden lg:flex gap-10 text-sm font-medium tracking-wide">
            <a
              href="#collections"
              className="hover:text-golden transition-colors text-white"
            >
              Collections
            </a>
            <a
              href="#celebration"
              className="hover:text-golden transition-colors text-white"
            >
              Celebration Cakes
            </a>
            <a
              href="#menu"
              className="hover:text-golden transition-colors text-white"
            >
              Patisserie & Breads
            </a>
            <a
              href="#story"
              className="hover:text-golden transition-colors text-white"
            >
              Our Story
            </a>
          </div>

          <div className="flex items-center gap-4 sm:gap-6">
            <span className="hidden md:inline text-[10px] font-bold uppercase tracking-widest text-golden/80">
              London, W1
            </span>
            <button
              onClick={() => setIsSearchOpen(true)}
              className="w-10 h-10 flex items-center justify-center text-white hover:text-golden transition-colors focus:outline-none"
              aria-label="Search"
            >
              <Search size={20} />
            </button>
            <button className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center text-xs relative hover:border-golden transition-colors text-white bg-white/5 backdrop-blur focus:outline-none overflow-visible">
              <ShoppingBag size={16} />
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-golden text-ink text-[10px] font-bold flex items-center justify-center rounded-full shadow-md z-10">
                3
              </span>
            </button>
          </div>
        </div>
      </nav>

      <SearchOverlay
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
      />

      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 z-[60] bg-black/40 backdrop-blur-sm lg:hidden"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            <motion.div
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", damping: 25, stiffness: 200 }}
              className="absolute top-0 left-0 bottom-0 w-4/5 max-w-sm bg-ink border-r border-white/5 shadow-2xl flex flex-col p-8"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex justify-between items-center mb-12">
                <div className="text-2xl font-bold tracking-tighter font-serif uppercase text-white">
                  SS<span className="text-golden font-light">BAKERY</span>
                </div>
                <button
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="p-2 border border-white/10 rounded-full text-stone-400 hover:text-white hover:border-golden transition-colors"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="flex flex-col gap-6 text-lg font-serif">
                <a
                  href="#collections"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="border-b border-white/10 pb-4 text-white hover:text-golden"
                >
                  Collections
                </a>
                <a
                  href="#celebration"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="border-b border-white/10 pb-4 text-white hover:text-golden"
                >
                  Celebration Cakes
                </a>
                <a
                  href="#menu"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="border-b border-white/10 pb-4 text-white hover:text-golden"
                >
                  Patisserie
                </a>
                <a
                  href="#menu"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="border-b border-white/10 pb-4 text-white hover:text-golden"
                >
                  Artisan Breads
                </a>
                <a
                  href="#story"
                  onClick={() => setIsMobileMenuOpen(false)}
                  className="border-b border-white/10 pb-4 text-white hover:text-golden"
                >
                  Our Story
                </a>
              </div>

              <div className="mt-auto pt-8 border-t border-white/10">
                <p className="text-xs font-bold uppercase tracking-widest text-golden/80 mb-2">
                  Visit Us
                </p>
                <p className="text-sm font-medium text-white">
                  124 Baker Street, London, W1U 6TY
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
