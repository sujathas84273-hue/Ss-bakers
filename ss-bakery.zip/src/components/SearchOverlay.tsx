import React, { useState, useEffect, useRef } from "react";
import {
  Search,
  X,
  Mic,
  ArrowRight,
  Clock,
  TrendingUp,
  Cake,
  ShoppingBag,
  MessageCircle,
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

const SEARCH_PLACEHOLDERS = [
  "Search chocolate cakes...",
  "Find fresh pastries...",
  "Search birthday cakes...",
  "Find eggless desserts...",
];

const BAKERY_PRODUCTS = [
  {
    id: 1,
    name: "Vanilla Bean Mille-Feuille",
    price: "₹1,000",
    category: "Pastries",
    tag: "Selling Fast",
    img: "https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&q=80&w=200",
    desc: "Layers of puff pastry and vanilla cream.",
  },
  {
    id: 2,
    name: "Almond Croissant",
    price: "₹500",
    category: "Croissants",
    tag: "Fresh",
    img: "https://images.unsplash.com/photo-1555507036-ab1f40ce88cb?auto=format&fit=crop&q=80&w=200",
    desc: "Twice baked with almond frangipane.",
  },
  {
    id: 3,
    name: "Classic Opera Cake",
    price: "₹3,800",
    category: "Cakes",
    tag: "",
    img: "https://images.unsplash.com/photo-1579697096985-41fe1430e5ef?auto=format&fit=crop&q=80&w=200",
    desc: "Coffee syrup soaked almond sponge.",
  },
  {
    id: 4,
    name: "Macaron Selection",
    price: "₹2,000",
    category: "Cookies",
    tag: "Loved",
    img: "https://images.unsplash.com/photo-1569864358642-9d1684040f43?auto=format&fit=crop&q=80&w=200",
    desc: "Assorted French macarons.",
  },
  {
    id: 5,
    name: "Black Forest Gateau",
    price: "₹4,600",
    category: "Cakes",
    tag: "Bestseller",
    img: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&q=80&w=200",
    desc: "Cherry, chocolate, and whipped cream.",
  },
  {
    id: 6,
    name: "Pistachio Éclair",
    price: "₹650",
    category: "Pastries",
    tag: "",
    img: "https://images.unsplash.com/photo-1612203985729-70726954388c?auto=format&fit=crop&q=80&w=200",
    desc: "Choux pastry filled with pistachio cream.",
  },
  {
    id: 7,
    name: "Sourdough Boule",
    price: "₹850",
    category: "Breads",
    tag: "Artisan",
    img: "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&q=80&w=200",
    desc: "Naturally leavened crusty bread.",
  },
  {
    id: 8,
    name: "Chocolate Chips Box",
    price: "₹1,500",
    category: "Cookies",
    tag: "",
    img: "https://images.unsplash.com/photo-1499636136210-6f4ee915583e?auto=format&fit=crop&q=80&w=200",
    desc: "Chewy, gooey chocolate chip cookies.",
  },
  {
    id: 9,
    name: "Eggless Truffle Cake",
    price: "₹3,500",
    category: "Cakes",
    tag: "Eggless",
    img: "https://images.unsplash.com/photo-1576717585968-ccea8820f04c?auto=format&fit=crop&q=80&w=200",
    desc: "Rich chocolate ganache without eggs.",
  },
  {
    id: 10,
    name: "Strawberry Shortcake",
    price: "₹4,200",
    category: "Cakes",
    tag: "Seasonal",
    img: "https://images.unsplash.com/photo-1563729784474-d77dbb933a9e?auto=format&fit=crop&q=80&w=200",
    desc: "Light sponge with fresh strawberries.",
  }
];

const OCCASIONS = [
  "Birthday",
  "Anniversary",
  "Wedding",
  "Baby Shower",
  "Festival",
];
const TRENDING = [
  "Chocolate Truffle",
  "Eggless Cakes",
  "Butter Croissant",
  "Macarons",
];
const RECENT = ["Red Velvet Cake", "Sourdough"];

interface SearchOverlayProps {
  isOpen: boolean;
  onClose: () => void;
}

export default function SearchOverlay({ isOpen, onClose }: SearchOverlayProps) {
  const [query, setQuery] = useState("");
  const [placeholderIndex, setPlaceholderIndex] = useState(0);
  const [isListening, setIsListening] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!isOpen) {
      setQuery("");
      return;
    }

    // Auto-focus input when opened
    setTimeout(() => {
      inputRef.current?.focus();
    }, 100);

    const interval = setInterval(() => {
      setPlaceholderIndex((prev) => (prev + 1) % SEARCH_PLACEHOLDERS.length);
    }, 3000);
    return () => clearInterval(interval);
  }, [isOpen]);

  const filteredProducts =
    query.trim() !== ""
      ? BAKERY_PRODUCTS.filter(
          (p) =>
            p.name.toLowerCase().includes(query.toLowerCase()) ||
            p.category.toLowerCase().includes(query.toLowerCase()) ||
            p.tag.toLowerCase().includes(query.toLowerCase()),
        )
      : [];

  const handleVoiceSearch = () => {
    // @ts-ignore
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Voice search is not supported in this browser. Please try Chrome or Edge.");
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-US";

    recognition.onstart = () => {
      setIsListening(true);
    };

    recognition.onresult = (event: any) => {
      const transcript = event.results[0][0].transcript;
      setQuery(transcript.replace(/\.$/, '')); // Remove trailing period from speech output
    };

    recognition.onerror = (event: any) => {
      console.error("Speech recognition error:", event.error);
      setIsListening(false);
    };

    recognition.onend = () => {
      setIsListening(false);
    };

    recognition.start();
  };

  // Lock body scroll when open
  useEffect(() => {
    if (isOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "";
    }
    return () => {
      document.body.style.overflow = "";
    };
  }, [isOpen]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3 }}
          className="fixed inset-0 z-[100] flex flex-col bg-ink/90 backdrop-blur-xl"
        >
          {/* Header & Search Bar */}
          <div className="w-full border-b border-white/10 bg-ink/40 shadow-sm sticky top-0 z-10">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 py-4 flex items-center gap-2 sm:gap-4">
              <div className="flex-1 relative flex items-center">
                <Search className="absolute left-4 text-stone-400 w-5 h-5 pointer-events-none" />
                <input
                  ref={inputRef}
                  type="text"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  className="w-full bg-white/5 focus:bg-white/10 text-white text-base sm:text-lg lg:text-xl rounded-2xl py-3 sm:py-4 pl-12 pr-12 focus:outline-none focus:ring-2 focus:ring-golden/50 transition-all border border-white/10 shadow-sm"
                />

                {/* Animated Placeholder - Only show if input is empty */}
                {!query && (
                  <div className="absolute left-12 right-12 top-0 bottom-0 pointer-events-none flex items-center overflow-hidden">
                    <AnimatePresence mode="wait">
                      <motion.span
                        key={placeholderIndex}
                        initial={{ opacity: 0, y: 10 }}
                        animate={{ opacity: 1, y: 0 }}
                        exit={{ opacity: 0, y: -10 }}
                        className="text-stone-400 text-base sm:text-lg lg:text-xl truncate"
                      >
                        {SEARCH_PLACEHOLDERS[placeholderIndex]}
                      </motion.span>
                    </AnimatePresence>
                  </div>
                )}

                <button 
                  onClick={handleVoiceSearch}
                  className={`absolute right-4 transition-colors group ${isListening ? 'text-red-500' : 'text-stone-400 hover:text-golden'}`}
                >
                  <Mic className={`w-5 h-5 transition-transform ${isListening ? 'animate-pulse scale-110' : 'group-hover:scale-110'}`} />
                </button>
              </div>
              <button
                 onClick={onClose}
                 className="w-10 h-10 sm:w-12 sm:h-12 rounded-full bg-white/5 flex items-center justify-center text-stone-400 hover:text-white hover:bg-white/10 transition-colors shadow-sm ml-2 shrink-0 border border-white/10"
              >
                <X className="w-5 h-5 sm:w-6 sm:h-6" />
              </button>
            </div>
          </div>

          {/* Search Content */}
          <div className="flex-1 overflow-y-auto">
            <div className="max-w-4xl mx-auto p-6 lg:py-10">
              {query === "" ? (
                /* Default State (Empty Query) */
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="space-y-12"
                >
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                    {/* Recent & Trending */}
                    <div className="space-y-8">
                      <div>
                        <h3 className="text-xs font-bold uppercase tracking-widest text-stone-400 mb-4 flex items-center gap-2">
                          <Clock size={14} /> Recent Searches
                        </h3>
                        <div className="flex flex-wrap gap-2">
                          {RECENT.map((item, i) => (
                            <button
                              key={i}
                              className="px-4 py-2 rounded-full bg-white/5 border border-white/10 text-sm hover:border-golden hover:text-golden text-stone-400 transition-colors shadow-sm"
                            >
                              {item}
                            </button>
                          ))}
                        </div>
                      </div>

                      <div>
                        <h3 className="text-xs font-bold uppercase tracking-widest text-stone-400 mb-4 flex items-center gap-2">
                          <TrendingUp size={14} /> Trending Now
                        </h3>
                        <div className="flex flex-wrap gap-2">
                          {TRENDING.map((item, i) => (
                            <button
                              key={i}
                              onClick={() => setQuery(item)}
                              className="px-4 py-2 rounded-full bg-golden/10 border border-transparent text-sm hover:bg-white/10 hover:border-golden/50 hover:text-white text-golden transition-colors flex items-center gap-2"
                            >
                              <Search size={12} className="text-golden/70" />{" "}
                              {item}
                            </button>
                          ))}
                        </div>
                      </div>
                    </div>

                    {/* Occasions */}
                    <div>
                      <h3 className="text-xs font-bold uppercase tracking-widest text-stone-400 mb-4 flex items-center gap-2">
                        <Cake size={14} /> Search by Occasion
                      </h3>
                      <div className="grid grid-cols-2 gap-3">
                        {OCCASIONS.map((occasion, i) => (
                          <button
                            key={i}
                            onClick={() => setQuery(occasion)}
                            className="bg-white/5 p-3 rounded-xl border border-white/10 text-left hover:border-golden/50 hover:shadow-lg transition-all group flex justify-between items-center"
                          >
                            <span className="font-medium text-stone-300 group-hover:text-golden transition-colors">
                              {occasion}
                            </span>
                            <ArrowRight
                              size={14}
                              className="text-stone-500 group-hover:text-golden transition-colors"
                            />
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Popular Featured */}
                  <div>
                    <h3 className="text-xs font-bold uppercase tracking-widest text-stone-400 mb-4 flex items-center gap-2">
                      <Search size={14} /> Popular Picks
                    </h3>
                    <div className="flex gap-4 overflow-x-auto pb-4 hide-scrollbar snap-x">
                      {BAKERY_PRODUCTS.slice(0, 4).map((product) => (
                        <div
                          key={product.id}
                          className="min-w-[160px] max-w-[160px] snap-start group cursor-pointer"
                          onClick={() => setQuery(product.name)}
                        >
                          <div className="rounded-2xl overflow-hidden aspect-square mb-3 relative bg-[#1a130f]">
                            <img
                              src={product.img}
                              alt={product.name}
                              className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                              loading="lazy"
                            />
                          </div>
                          <h4 className="font-serif text-sm leading-tight text-white group-hover:text-golden transition-colors line-clamp-1">
                            {product.name}
                          </h4>
                          <span className="text-xs font-bold text-golden">
                            {product.price}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                </motion.div>
              ) : (
                /* Search Results (With Query) */
                <motion.div
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  className="space-y-6"
                >
                  <p className="text-sm text-stone-400 mb-4">
                    Showing results for{" "}
                    <span className="font-bold text-white">"{query}"</span>
                  </p>

                  {filteredProducts.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-4">
                      {filteredProducts.map((product, i) => (
                        <motion.div
                          initial={{ opacity: 0, y: 10 }}
                          animate={{ opacity: 1, y: 0 }}
                          transition={{ delay: i * 0.05 }}
                          key={product.id}
                          className="bg-white/5 p-4 rounded-3xl border border-white/10 flex gap-4 hover:shadow-lg transition-all group hover:border-golden/30"
                        >
                          <div className="w-24 h-24 sm:w-32 sm:h-32 shrink-0 rounded-2xl overflow-hidden bg-[#1a130f] relative border border-white/5">
                            <img
                              src={product.img}
                              alt={product.name}
                              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                              loading="lazy"
                            />
                            {product.tag && (
                              <div className="absolute top-2 left-2 bg-ink/90 backdrop-blur px-2 py-0.5 rounded text-[8px] font-bold uppercase tracking-widest shadow-sm text-golden border border-golden/30">
                                {product.tag}
                              </div>
                            )}
                          </div>
                          <div className="flex flex-col justify-center flex-1">
                            <h4 className="font-serif text-lg leading-tight text-white mb-1 group-hover:text-golden transition-colors">
                              {product.name}
                            </h4>
                            <p className="text-xs text-stone-400 mb-2 line-clamp-2">
                              {product.desc}
                            </p>
                            <div className="mt-auto flex items-center justify-between">
                              <span className="text-sm font-bold text-golden">
                                {product.price}
                              </span>
                              <div className="flex gap-2">
                                <button
                                  className="w-8 h-8 rounded-full bg-white/10 text-white flex items-center justify-center hover:bg-golden hover:text-ink transition-colors"
                                  title="Add to Bag"
                                >
                                  <ShoppingBag size={14} />
                                </button>
                                <a
                                  href={`https://wa.me/1234567890?text=I'm interested in ${product.name}`}
                                  target="_blank"
                                  rel="noopener noreferrer"
                                  className="w-8 h-8 rounded-full bg-golden/10 text-golden flex items-center justify-center hover:bg-golden hover:text-ink transition-colors"
                                  title="Order on WhatsApp"
                                >
                                  <MessageCircle size={14} />
                                </a>
                              </div>
                            </div>
                          </div>
                        </motion.div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-20">
                      <div className="w-20 h-20 rounded-full bg-white/5 border border-white/10 shadow-sm flex items-center justify-center mx-auto mb-6 text-stone-500">
                        <Search size={32} />
                      </div>
                      <h3 className="text-xl font-serif text-white mb-2">
                        No bakery items found
                      </h3>
                      <p className="text-sm text-stone-400 max-w-sm mx-auto mb-8">
                        We couldn't find any cakes, pastries, or breads matching
                        "{query}". Try searching for occasion or flavor.
                      </p>
                      <button
                        onClick={() => setQuery("")}
                        className="px-6 py-2 border border-white/20 rounded-full text-xs font-bold uppercase tracking-widest text-stone-300 hover:bg-white/10 transition-colors hover:text-white"
                      >
                        Clear Search
                      </button>
                    </div>
                  )}
                </motion.div>
              )}
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
