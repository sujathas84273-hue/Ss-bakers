import React from 'react';
import { Cake, ChevronRight, Sparkles } from 'lucide-react';
import { motion } from 'motion/react';

export default function CustomCakeSection() {
  return (
    <section id="celebration" className="py-32 bg-ink relative overflow-hidden border-t border-white/5">
      {/* Cinematic Lighting Effect */}
      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1/2 aspect-[1/1] bg-golden/10 rounded-full blur-[150px] pointer-events-none"></div>
      <div className="absolute left-[-10%] top-[-10%] w-1/3 aspect-[1/1] bg-[#FEE5D9]/5 rounded-full blur-[100px] pointer-events-none"></div>
      
      <div className="max-w-7xl mx-auto px-6 lg:px-10 relative z-10 flex flex-col lg:flex-row gap-20 items-center">
        <motion.div 
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1, type: "spring", stiffness: 50 }}
          className="w-full lg:w-1/2"
        >
          <div className="relative rounded-[2.5rem] sm:rounded-[3rem] overflow-hidden aspect-square sm:aspect-[4/5] p-1 glass-card shadow-[0_30px_60px_-15px_rgba(0,0,0,0.8)] group">
            <div className="absolute inset-0 bg-gradient-to-br from-golden/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none"></div>
            <img 
              src="https://images.unsplash.com/photo-1535141192574-5d4897c12636?auto=format&fit=crop&q=80&w=1000" 
              alt="Custom Wedding Cake" 
              className="w-full h-full object-cover rounded-[2.5rem] transition-transform duration-[20s] ease-out group-hover:scale-110" 
              loading="lazy"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-ink/90 via-ink/20 to-transparent rounded-[2.5rem]"></div>

            <div className="absolute bottom-10 left-10 right-10 flex flex-col gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-golden/20 backdrop-blur-md flex items-center justify-center text-golden border border-golden/30">
                  <Sparkles size={18} />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-golden">Bespoke Collection</span>
              </div>
              <p className="text-serif text-2xl lg:text-3xl border-l-[3px] border-golden pl-6 italic text-white font-light drop-shadow-md">
                "Not just a cake, but a masterpiece that tasted even better than it looked."
              </p>
            </div>
          </div>
        </motion.div>
        
        <motion.div 
          initial={{ opacity: 0, x: 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1, delay: 0.2, type: "spring", stiffness: 50 }}
          className="w-full lg:w-1/2 flex flex-col justify-center"
        >
          <div className="flex items-center gap-3 mb-6">
             <div className="w-12 h-[1px] bg-golden"></div>
             <span className="text-xs font-bold uppercase tracking-widest text-golden">Artisan Craft</span>
          </div>
          <h2 className="text-4xl md:text-5xl lg:text-7xl text-serif text-white tracking-tight mb-6 sm:mb-8">
            Design Your <br/>
            <span className="italic text-transparent text-gradient-gold">Perfect Masterpiece</span>
          </h2>
          <p className="text-base sm:text-lg text-stone-400 mb-10 sm:mb-12 leading-relaxed max-w-xl font-light">
            From intimate birthdays to grand weddings, begin your bespoke cake journey with our master bakers. Select premium flavors, distinctive themes, and request a uniquely personalized design.
          </p>
          
          <form className="glass-card rounded-[2rem] sm:rounded-[2.5rem] p-6 sm:p-8 lg:p-10 shadow-2xl relative overflow-hidden group">
            <div className="absolute inset-0 border border-white/5 rounded-[2rem] sm:rounded-[2.5rem] pointer-events-none group-hover:border-golden/20 transition-colors duration-500"></div>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8 max-w-xl relative z-10">
              <div className="flex flex-col gap-3">
                <label className="text-[10px] font-bold uppercase tracking-widest text-golden/80">Occasion</label>
                <select className="border-b border-white/20 py-2 focus:outline-none focus:border-golden bg-transparent font-medium text-white cursor-pointer transition-colors appearance-none">
                  <option className="bg-ink">Birthday</option>
                  <option className="bg-ink">Wedding</option>
                  <option className="bg-ink">Anniversary</option>
                  <option className="bg-ink">Baby Shower</option>
                </select>
              </div>
              <div className="flex flex-col gap-3">
                <label className="text-[10px] font-bold uppercase tracking-widest text-golden/80">Date Needed</label>
                <input type="date" className="border-b border-white/20 py-2 focus:outline-none focus:border-golden bg-transparent font-medium text-white cursor-pointer transition-colors" style={{ colorScheme: 'dark' }} />
              </div>
              <div className="flex flex-col gap-3">
                <label className="text-[10px] font-bold uppercase tracking-widest text-golden/80">Flavor Profile</label>
                <select className="border-b border-white/20 py-2 focus:outline-none focus:border-golden bg-transparent font-medium text-white cursor-pointer transition-colors appearance-none">
                  <option className="bg-ink">Madagascar Vanilla</option>
                  <option className="bg-ink">Valrhona Chocolate</option>
                  <option className="bg-ink">Pistachio Rose</option>
                  <option className="bg-ink">Lemon Raspberry</option>
                </select>
              </div>
              <div className="flex flex-col gap-3">
                <label className="text-[10px] font-bold uppercase tracking-widest text-golden/80">Guest Count</label>
                <select className="border-b border-white/20 py-2 focus:outline-none focus:border-golden bg-transparent font-medium text-white cursor-pointer transition-colors appearance-none">
                  <option className="bg-ink">10-20 Guests</option>
                  <option className="bg-ink">20-50 Guests</option>
                  <option className="bg-ink">50-100 Guests</option>
                  <option className="bg-ink">100+ Guests</option>
                </select>
              </div>
              
              <button type="button" className="col-span-1 sm:col-span-2 bg-golden text-ink rounded-2xl py-5 mt-6 font-bold uppercase tracking-widest text-xs hover:bg-white transition-all shadow-[0_0_30px_rgba(196,155,102,0.2)] hover:shadow-[0_0_40px_rgba(255,255,255,0.4)] flex items-center justify-center gap-3 group">
                Request Consultation 
                <ChevronRight size={16} className="transform group-hover:translate-x-2 transition-transform duration-300" />
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </section>
  );
}
