import React from "react";

export default function Footer() {
  return (
    <footer className="bg-[#1A120B] text-stone-400 py-16 px-6 lg:px-10 mt-auto">
      <div className="max-w-7xl mx-auto flex flex-col lg:flex-row justify-between items-center lg:items-start gap-12">
        <div className="flex flex-col items-center lg:items-start gap-6">
          <div className="text-3xl font-bold tracking-tighter text-serif uppercase text-white">
            SS<span className="text-stone-500 font-light">BAKERY</span>
          </div>
          <p className="text-sm max-w-xs text-center lg:text-left text-stone-500 leading-relaxed">
            Crafting spectacular moments through the finest patisserie and
            luxury cakes in London.
          </p>
          <div className="flex gap-4">
            <button className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors cursor-pointer border border-white/5 focus:outline-none">
              <span className="text-white font-serif italic text-lg">in</span>
            </button>
            <button className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors cursor-pointer border border-white/5 focus:outline-none">
              <span className="text-white font-serif italic text-lg">fb</span>
            </button>
          </div>
        </div>

        <div className="flex flex-wrap justify-center lg:justify-end gap-16 lg:gap-24 text-sm w-full lg:w-auto">
          <div className="flex flex-col items-center lg:items-start gap-4">
            <span className="text-white font-bold uppercase tracking-widest text-[10px] mb-2">
              Shop
            </span>
            <a href="#" className="hover:text-golden transition-colors py-1">
              All Cakes
            </a>
            <a href="#" className="hover:text-golden transition-colors py-1">
              Patisserie
            </a>
            <a href="#" className="hover:text-golden transition-colors py-1">
              Breads
            </a>
            <a href="#" className="hover:text-golden transition-colors py-1">
              Gifting
            </a>
          </div>
          <div className="flex flex-col items-center lg:items-start gap-4">
            <span className="text-white font-bold uppercase tracking-widest text-[10px] mb-2">
              Service
            </span>
            <a href="#" className="hover:text-golden transition-colors py-1">
              Custom Orders
            </a>
            <a href="#" className="hover:text-golden transition-colors py-1">
              Delivery Info
            </a>
            <a href="#" className="hover:text-golden transition-colors py-1">
              Contact
            </a>
            <a href="#" className="hover:text-golden transition-colors py-1">
              FAQ
            </a>
          </div>
          <div className="flex flex-col items-center lg:items-start gap-4 text-center lg:text-left">
            <span className="text-white font-bold uppercase tracking-widest text-[10px] mb-2">
              Visit Us
            </span>
            <span className="text-stone-500">
              124 Baker Street
              <br />
              London, W1U 6TY
            </span>
            <span className="text-stone-500">Mon-Sun: 8am - 8pm</span>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mt-16 pt-8 border-t border-white/10 flex flex-col sm:flex-row justify-between items-center gap-4 text-[10px] uppercase tracking-widest">
        <div className="flex items-center gap-2">
          <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
          <span className="font-bold text-white">
            Kitchen Open & Taking Orders
          </span>
        </div>
        <span>© 2024 SS Bakery. Crafted with obsession.</span>
      </div>
    </footer>
  );
}
