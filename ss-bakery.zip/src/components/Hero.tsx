import React from "react";
import { Clock, ChevronRight, Play } from "lucide-react";
import { motion } from "motion/react";

export default function Hero() {
  return (
    <main className="relative flex items-center min-h-screen lg:min-h-[100vh] pt-20 bg-ink overflow-hidden border-b border-white/10">
      {/* Cinematic Background */}
      <div className="absolute inset-0 z-0">
        <div
          className="absolute inset-0 bg-cover bg-center opacity-50 animate-kenburns"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1558961363-fa8fdf82db35?auto=format&fit=crop&q=80&w=2000')",
          }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-ink via-ink/80 to-transparent"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-ink/30 via-transparent to-ink"></div>
      </div>

      <div className="max-w-7xl mx-auto px-6 lg:px-10 w-full relative z-10 flex flex-col lg:flex-row items-center gap-16 py-12 lg:py-0">
        <section className="w-full lg:w-3/5 flex flex-col justify-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mb-8 flex gap-3 flex-wrap"
          >
            <span className="pill bg-golden/10 text-golden border border-golden/20 backdrop-blur-md flex items-center gap-2 px-4 py-2">
              <Clock size={12} /> Freshly Baked 06:00 AM
            </span>
            <span className="pill bg-white/5 text-white border border-white/10 backdrop-blur-md flex items-center gap-2 px-4 py-2">
              <span className="text-golden">★</span> 5.0 (4.2k Reviews)
            </span>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-4xl sm:text-6xl lg:text-7xl xl:text-8xl leading-[1.1] text-serif font-light mb-6 sm:mb-8 text-white"
          >
            The Art of <br />
            <span className="italic text-golden drop-shadow-lg">
              the Sweet
            </span>{" "}
            Moment.
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="text-base sm:text-lg lg:text-xl text-stone-300 max-w-lg leading-relaxed mb-8 sm:mb-10 font-light"
          >
            Handcrafted luxury pastries and bespoke celebration cakes designed to
            transform everyday moments into golden memories.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
            className="flex flex-col sm:flex-row gap-4 sm:gap-6"
          >
            <button className="px-6 sm:px-8 py-4 bg-golden text-ink rounded-full font-bold uppercase tracking-widest text-xs shadow-[0_0_40px_rgba(196,155,102,0.3)] hover:bg-white hover:text-ink hover:shadow-[0_0_60px_rgba(255,255,255,0.4)] transition-all duration-500 cursor-pointer flex items-center justify-center gap-3 group">
              Order Fresh Cakes
              <ChevronRight
                size={16}
                className="group-hover:translate-x-1 transition-transform"
              />
            </button>
            <button className="px-6 sm:px-8 py-4 border border-white/20 text-white rounded-full font-bold uppercase tracking-widest text-xs hover:bg-white/10 hover:border-white/40 transition-colors duration-500 cursor-pointer backdrop-blur-sm flex items-center justify-center gap-3">
              <Play size={16} className="text-golden fill-golden" /> Watch Our Story
            </button>
          </motion.div>
        </section>

        <section className="w-full lg:w-2/5 relative mt-12 lg:mt-0 pb-12 lg:pb-0">
          <motion.div
            initial={{ opacity: 0, scale: 0.9, rotate: 2 }}
            animate={{ opacity: 1, scale: 1, rotate: 0 }}
            transition={{ duration: 1.2, delay: 0.5, type: "spring" }}
            className="relative z-10"
          >
            <div className="absolute inset-0 bg-golden/20 blur-[100px] rounded-full transform -translate-x-1/4 -translate-y-1/4 z-0"></div>

            <div className="relative z-10 bg-white/5 backdrop-blur-3xl border border-white/10 p-4 rounded-[2.5rem] shadow-2xl overflow-hidden group hover:border-golden/40 transition-colors duration-500">
              <div className="absolute inset-0 bg-gradient-to-br from-white/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
              <div className="h-[350px] sm:h-[400px] lg:h-[500px] w-full rounded-[2rem] overflow-hidden relative">
                <img
                  src="https://images.unsplash.com/photo-1488477181946-6428a0291777?auto=format&fit=crop&q=80&w=800"
                  alt="Signature Cake"
                  className="w-full h-full object-cover transform group-hover:scale-110 transition-transform duration-1000"
                  loading="eager"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-ink/90 via-transparent to-transparent"></div>

                <div className="absolute bottom-0 left-0 right-0 p-6 flex justify-between items-end">
                  <div>
                    <div className="text-[10px] font-bold text-golden uppercase tracking-widest mb-2">
                      Signature Collection
                    </div>
                    <h3 className="text-2xl font-serif text-white mb-1">
                      Raspberry Choux
                    </h3>
                    <p className="text-sm text-stone-300">
                      Madagascar vanilla & fresh berries
                    </p>
                  </div>
                  <div className="w-12 h-12 rounded-full bg-golden/20 backdrop-blur-md flex items-center justify-center border border-golden/30 text-golden group-hover:bg-golden group-hover:text-ink transition-colors duration-500 cursor-pointer shrink-0">
                    <ChevronRight size={20} />
                  </div>
                </div>
              </div>
            </div>

            {/* Floating badge */}
            <motion.div
              animate={{ y: [0, -10, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
              className="absolute -right-4 lg:-right-8 -bottom-6 bg-ink border border-golden/30 p-4 rounded-3xl shadow-2xl backdrop-blur-md z-20 flex items-center gap-4 hidden sm:flex"
            >
              <div className="w-12 h-12 rounded-full overflow-hidden border border-white/10">
                <img
                  src="https://images.unsplash.com/photo-1577219491135-ce391730fb2c?auto=format&fit=crop&q=80&w=200"
                  alt="Chef"
                  className="w-full h-full object-cover"
                />
              </div>
              <div>
                <p className="text-[10px] text-stone-400 uppercase tracking-widest">
                  Master Baker
                </p>
                <p className="text-white font-serif text-sm">Pierre Hermé</p>
              </div>
            </motion.div>
          </motion.div>
        </section>
      </div>
    </main>
  );
}
