import React from "react";
import { motion } from "motion/react";

export default function FloatingWhatsApp() {
  return (
    <>
      <style>{`
        .floating-wa { 
          position: fixed; 
          bottom: 24px; 
          right: 24px; 
          background: #25D366; 
          color: white; 
          padding: 12px 24px; 
          border-radius: 50px; 
          box-shadow: 0 10px 20px rgba(37, 211, 102, 0.3); 
          font-weight: 600; 
          display: flex; 
          align-items: center; 
          gap: 8px; 
          z-index: 50; 
          font-size: 14px;
          text-transform: uppercase;
          letter-spacing: 0.05em;
          transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .floating-wa:hover {
          transform: translateY(-2px);
          box-shadow: 0 12px 24px rgba(37, 211, 102, 0.4);
        }
      `}</style>
      <motion.a
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 1.5, type: "spring", stiffness: 200 }}
        href="https://wa.me/1234567890"
        target="_blank"
        rel="noopener noreferrer"
        className="floating-wa decoration-transparent"
      >
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.38 2.27 1.019 3.287l-.582 2.128 2.185-.573c.948.517 1.933.887 3.146.888h.001c3.181 0 5.767-2.586 5.768-5.766 0-3.18-2.587-5.766-5.77-5.766zm3.361 8.21c-.144.405-.833.743-1.159.791-.326.048-.652.084-1.847-.384-1.203-.473-1.954-1.64-2.015-1.722-.061-.082-.49-.652-.49-1.246 0-.594.307-.887.429-1.009.123-.123.266-.154.348-.154.082 0 .164 0 .235.003.072.003.172-.027.27.208l.379.921c.041.103.072.226.001.369-.071.144-.103.226-.205.348-.102.123-.215.277-.307.369-.102.103-.21.215-.091.41.12.195.534.887 1.15 1.436.791.708 1.46.927 1.664 1.031.205.103.326.082.449-.061.122-.144.534-.626.674-.838.144-.215.287-.184.482-.113s1.231.585 1.446.693c.215.113.359.164.41.256.051.092.051.534-.093.939z" />
        </svg>
        Chat on WhatsApp
      </motion.a>
    </>
  );
}
