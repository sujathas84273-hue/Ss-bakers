import React, { useState } from 'react';
import { ShoppingBag } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

const CATEGORIES = ['All', 'Cakes', 'Pastries', 'Croissants', 'Cookies'];

const MENU_ITEMS = [
  {
    id: 1,
    name: "Vanilla Bean Mille-Feuille",
    price: "₹1,000",
    category: "Pastries",
    tag: "Selling Fast",
    img: "https://images.unsplash.com/photo-1587314168485-3236d6710814?auto=format&fit=crop&q=80&w=600",
  },
  {
    id: 2,
    name: "Almond Croissant",
    price: "₹500",
    category: "Croissants",
    tag: "Fresh Out of Oven",
    img: "https://images.unsplash.com/photo-1555507036-ab1f40ce88cb?auto=format&fit=crop&q=80&w=600",
  },
  {
    id: 3,
    name: "Classic Opera Cake",
    price: "₹3,800",
    category: "Cakes",
    tag: "",
    img: "https://images.unsplash.com/photo-1579697096985-41fe1430e5ef?auto=format&fit=crop&q=80&w=600",
  },
  {
    id: 4,
    name: "Macaron Selection",
    price: "₹2,000",
    category: "Cookies",
    tag: "Loved",
    img: "https://images.unsplash.com/photo-1569864358642-9d1684040f43?auto=format&fit=crop&q=80&w=600",
  },
  {
    id: 5,
    name: "Black Forest Gateau",
    price: "₹4,600",
    category: "Cakes",
    tag: "Bestseller",
    img: "https://images.unsplash.com/photo-1578985545062-69928b1d9587?auto=format&fit=crop&q=80&w=600",
  },
  {
    id: 6,
    name: "Pistachio Éclair",
    price: "₹650",
    category: "Pastries",
    tag: "",
    img: "https://images.unsplash.com/photo-1612203985729-70726954388c?auto=format&fit=crop&q=80&w=600",
  },
  {
    id: 7,
    name: "Sourdough Boule",
    price: "₹850",
    category: "Breads",
    tag: "Artisan",
    img: "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&q=80&w=600",
  },
  {
    id: 8,
    name: "Chocolate Chips Box",
    price: "₹1,500",
    category: "Cookies",
    tag: "",
    img: "https://images.unsplash.com/photo-1499636136210-6f4ee915583e?auto=format&fit=crop&q=80&w=600",
  },
];

export default function MenuSection() {
  const [activeCategory, setActiveCategory] = useState("All");

  const filteredItems =
    activeCategory === "All"
      ? MENU_ITEMS
      : MENU_ITEMS.filter((item) => item.category === activeCategory);

  return (
    <section
      id="collections"
      className="py-32 px-6 lg:px-10 max-w-7xl mx-auto w-full relative"
    >
      <div className="absolute top-0 right-0 w-1/2 aspect-square bg-golden/5 blur-[120px] rounded-full pointer-events-none"></div>

      <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8 relative z-10">
        <div className="max-w-2xl">
          <span className="text-xs font-bold uppercase tracking-widest text-golden mb-4 block">
            Our Patisserie
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-7xl text-serif text-white tracking-tight">
            A Symphony of <br />
            <span className="italic text-stone-400 drop-shadow-md">Sweetness</span>
          </h2>
        </div>
        <div className="flex gap-3 overflow-x-auto pb-4 w-full md:w-auto snap-x hide-scrollbar border-b border-white/10">
          {CATEGORIES.map((cat) => (
            <button
              key={cat}
              onClick={() => setActiveCategory(cat)}
              className={`px-6 py-3 rounded-full text-[10px] font-bold uppercase tracking-widest whitespace-nowrap snap-center shrink-0 transition-all duration-300 ${
                activeCategory === cat
                  ? "bg-golden text-ink shadow-[0_0_20px_rgba(196,155,102,0.3)]"
                  : "bg-transparent text-stone-400 hover:text-white"
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      <motion.div
        layout
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10"
      >
        <AnimatePresence mode="popLayout">
          {filteredItems.map((item) => (
            <motion.div
              key={item.id}
              layout
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.95 }}
              transition={{ duration: 0.4 }}
              className="group cursor-pointer flex flex-col"
            >
              <div className="relative overflow-hidden rounded-[2.5rem] aspect-square sm:aspect-[4/5] bg-[#1a130f] mb-6 border border-white/5 group-hover:border-golden/30 transition-all duration-700 shadow-lg group-hover:shadow-[0_20px_40px_-15px_rgba(196,155,102,0.2)]">
                <img
                  src={item.img}
                  alt={item.name}
                  className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-110 opacity-90 group-hover:opacity-100"
                  loading="lazy"
                />
                
                {item.tag && (
                  <div className="absolute top-4 left-4 bg-ink/80 backdrop-blur-md border border-golden/30 px-4 py-1.5 rounded-full text-[9px] font-bold uppercase tracking-widest text-golden z-10 shadow-lg">
                    {item.tag}
                  </div>
                )}
                
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex flex-col justify-end p-6">
                  <button className="w-full py-4 bg-golden text-ink rounded-2xl text-xs font-bold uppercase tracking-widest hover:bg-white transition-colors flex items-center justify-center gap-2 transform translate-y-8 group-hover:translate-y-0 duration-500 shadow-xl">
                    <ShoppingBag size={14} /> Add to Bag
                  </button>
                </div>
              </div>
              <div className="flex justify-between items-start gap-4 px-2">
                <h3 className="font-serif text-xl leading-tight text-white group-hover:text-golden transition-colors">
                  {item.name}
                </h3>
                <span className="font-sans font-medium text-golden">{item.price}</span>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </motion.div>

      <div className="mt-20 flex justify-center relative z-10">
        <button className="px-10 py-5 border border-golden/50 text-golden rounded-full text-xs font-bold uppercase tracking-widest hover:bg-golden hover:text-ink transition-all duration-300">
          View Full Menu
        </button>
      </div>
    </section>
  );
}
