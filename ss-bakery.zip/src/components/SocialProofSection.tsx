import React from 'react';
import { Heart, Instagram } from 'lucide-react';
import { motion } from 'motion/react';

const IMAGES = [
  "https://images.unsplash.com/photo-1542826438-bd32f43d626f?auto=format&fit=crop&q=80&w=600",
  "https://images.unsplash.com/photo-1602351447937-745cb720612f?auto=format&fit=crop&q=80&w=600",
  "https://images.unsplash.com/photo-1509440159596-0249088772ff?auto=format&fit=crop&q=80&w=600",
  "https://images.unsplash.com/photo-1517409249704-f584e0c4fe30?auto=format&fit=crop&q=80&w=600"
];

export default function SocialProofSection() {
  return (
    <section className="py-32 px-6 lg:px-10 max-w-7xl mx-auto text-center border-t border-white/5 relative">
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-full h-[500px] bg-golden/5 blur-[150px] rounded-[100%] pointer-events-none"></div>

      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        className="flex items-center justify-center gap-2 mb-6"
      >
        <Instagram size={14} className="text-golden" />
        <span className="text-[10px] font-bold uppercase tracking-widest text-golden block">
          Join the Community
        </span>
      </motion.div>
      
      <motion.h2 
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ delay: 0.1 }}
        className="text-4xl md:text-5xl lg:text-7xl text-serif text-white tracking-tight mb-20 relative z-10"
      >
        Golden <span className="italic text-transparent text-gradient-gold drop-shadow-sm">Moments</span>
      </motion.h2>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 relative z-10">
        {IMAGES.map((img, i) => (
          <motion.div 
            key={i}
            initial={{ opacity: 0, y: 40 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: i * 0.1, duration: 0.8, type: "spring" }}
            className={`rounded-[2.5rem] overflow-hidden group relative bg-ink border border-white/10 shadow-2xl ${i % 2 !== 0 ? 'lg:mt-16' : ''}`}
          >
            <div className="absolute inset-0 bg-gradient-to-t from-ink/90 via-transparent to-transparent z-10 opacity-60 group-hover:opacity-80 transition-opacity duration-500"></div>
            <img src={img} alt="Instagram Moment" className="w-full aspect-[4/5] object-cover opacity-80 group-hover:opacity-100 group-hover:scale-110 transition-all duration-1000" loading="lazy" />
            
            <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-500 z-20">
              <div className="w-16 h-16 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center border border-white/20 transform scale-50 group-hover:scale-100 transition-transform duration-500 delay-100">
                <Heart className="text-white w-6 h-6" />
              </div>
            </div>
            
            <div className="absolute bottom-6 left-6 right-6 text-left opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-200 z-20 flex items-center gap-3">
               <div className="w-8 h-8 rounded-full bg-golden/20 flex items-center justify-center">
                 <Instagram size={14} className="text-white" />
               </div>
               <span className="text-white text-xs font-bold tracking-widest uppercase drop-shadow-md cursor-pointer hover:text-golden transition-colors">@SSBAKERY</span>
            </div>
          </motion.div>
        ))}
      </div>
      
      <motion.div 
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ delay: 0.6 }}
        className="mt-20 relative z-10"
      >
        <button className="px-10 py-5 bg-transparent border border-white/20 text-white rounded-full text-xs font-bold uppercase tracking-widest hover:border-golden hover:text-golden transition-all duration-300">
          Follow on Instagram
        </button>
      </motion.div>
    </section>
  );
}
