import React from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import MenuSection from "./components/MenuSection";
import CustomCakeSection from "./components/CustomCakeSection";
import SocialProofSection from "./components/SocialProofSection";
import Footer from "./components/Footer";
import FloatingWhatsApp from "./components/FloatingWhatsApp";

export default function App() {
  return (
    <div className="flex flex-col min-h-screen bg-cream text-ink font-sans overflow-x-hidden selection:bg-golden/30 selection:text-ink">
      <Navbar />
      <Hero />
      <MenuSection />
      <CustomCakeSection />
      <SocialProofSection />
      <Footer />
      <FloatingWhatsApp />
    </div>
  );
}
